<template>
  <div>
    <h1>두 번째 페이지입니다</h1>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'SecondView',
  components: {
  }
}
</script>

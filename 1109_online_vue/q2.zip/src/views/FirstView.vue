<template>
  <div>
    <img src="@/assets/logo.png" alt="logo">
    <HelloWorld msg="첫 번째 페이지입니다"/>
  </div>
</template>

<script>
import HelloWorld from "@/components/HelloWorld"

export default {
  name: 'FirstView',
  components: {
    HelloWorld,
  }
}
</script>
